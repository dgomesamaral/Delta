var fs = require('fs');
var found = 0
console.log("Reading file 1...");

fs.readFileSync('FLOCS.csv').toString().split('\n').forEach((content, index, array) => {
    if (index !== 0) {
        content = content.trim();
        var fields = content.split(';')

        var name = fields[1]
        var found = 0;
        console.log(name);
        
        fs.readFileSync('FLOCS_ACC.csv').toString().split('\n').forEach((content, index, array) => {
            if (index !== 0) {
                contentACC = content.trim();
                var fieldsACC = contentACC.split(';')
        
                var nameACC = fieldsACC[1]
        
                if (name == nameACC) {
                    found = 1
                }  
            }
        })

        if (found == 0) {
            LoggingUtil('delta.txt', name)
        }
        
    }
})

console.log("Stopped reading file 1...");

function LoggingUtil(file, content) {
    fs.appendFile(file, content + '\n', (err) => {
        if (err) throw err;
    })
}
